#include "test1.h"

int main(int argc, char** argv){
	ANONYMOUS::main__Wrapper();
}
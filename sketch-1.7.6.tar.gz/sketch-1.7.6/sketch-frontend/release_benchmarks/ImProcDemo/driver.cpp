#include "HFILE"

#include <cstring>

int main(int argc, char** argv){
	ANONYMOUS::main__Wrapper(strlen(argv[1])+1, argv[1]);
}

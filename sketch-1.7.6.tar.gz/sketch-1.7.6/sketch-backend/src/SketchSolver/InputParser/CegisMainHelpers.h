

#include "CegisCApi.h"
    // void runDriver();
    // InterpreterEnvironment* getEnvt();

void printStats ();
void AssertionHandler(int signal);
void CtrlCHandler(int signal);
void TerminationHandler(int signal);
void DumpSignalHandler(int signal);